import java.awt.Color;
import java.awt.Component;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;

public class CountryTable extends AbstractTableModel {
	public String countriesFileName;
    private List<Country> countryList = new ArrayList<>();
    private String columName[] = new String[4];

    public CountryTable(String countriesFileName) {
        this.countriesFileName = countriesFileName;
    }

    public JTable create() throws IOException {
        FileReader fileReader = new FileReader(countriesFileName);
        String p1 = "";
        int p2;

        while ((p2 = fileReader.read()) != -1) {
            p1 += (char) p2;
        }

        StringTokenizer stringTokenizer = new StringTokenizer(p1, ".");
        for (int i = 0; i < 4; i++) {
            columName[i] = stringTokenizer.nextToken();
        }

        while (stringTokenizer.hasMoreTokens()) {
            countryList.add(new Country(stringTokenizer.nextToken(), stringTokenizer.nextToken(), Integer.parseInt(stringTokenizer.nextToken()), stringTokenizer.nextToken()));
        }

        JTable jTable = new JTable(this) {
            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                Component comp = super.prepareRenderer(renderer, row, column);
                if (column == 2) {
                    int populationAbove = Integer.parseInt(getValueAt(row, 2).toString());
                    if (populationAbove > 20000000) {
                        comp.setForeground(Color.red);
                    } else {
                        comp.setForeground(Color.black);
                    }
                }
                return comp;
            }
        };
        return jTable;
    }

    @Override
    public int getRowCount() {
        return countryList.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public String getColumnName(int column) {
        return columName[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return getValueAt(2, columnIndex).getClass();
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Country country = countryList.get(rowIndex);
        if (columnIndex == 0) {
            return country.getName();
        } else if (columnIndex == 1) {
            return country.getCapital();
        } else if (columnIndex == 2) {
            return country.getPopulation();
        } else if (columnIndex == 3) {
            return country.getFlag();
        } else {
            return null;
        }
    }
}
