/**
 *
 *  @author Çatal Enes S26138
 *
 */

package zad1;



import java.util.*;

public class Main {
  public Main() {
    List<Integer> src1 = Arrays.asList(1, 7, 9, 11, 12);/*<-- here you should initialize elements of the first list */
    System.out.println(test1(src1));

    List<String> src2 = Arrays.asList("a", "zzzz", "vvvvvvv");/*<-- here you should initialize elements of the second list */
    System.out.println(test2(src2));
  }

  public List<Integer> test1(List<Integer> src) {
    Selector<Integer> sel = new Selector<Integer>() {/*<-- definition of selector; lambda-expressions are not allowed; variable name sel */
    	@Override
    	public boolean select(Integer type) {
    		if(type < 10) {
    			return true;
    		}else {
    			return false;
    		}
    	}
    };
    Mapper<Integer,Integer> map = new Mapper<Integer,Integer>(){/*<-- definition of mapper; lambda-expressions are not allowed; variable name map */
    	@Override
    	public Integer map(Integer otherType) {
    		otherType += 10;
    		return otherType;
    	}
    };
    return   /*<-- return of the result 
      which is obtained by invocation of static method of ListCreator class:
     */  ListCreator.collectFrom(src).when(sel).mapEvery(map);
  }

  public List<Integer> test2(List<String> src) {
    Selector<String> sel = new Selector<String>(){/*<-- definition of selector; lambda-expressions are not allowed; variable name sel */
    	@Override
    	public boolean select(String type) {
    		if(type.length() > 3) {
    			return true;
    		}else {
    			return false;
    		}
    	}
    };
    Mapper<String, Integer> map = new Mapper<String,Integer>(){/*<-- definition of mapper; lambda-expressions are not allowed; variable name map */
    	@Override
    	public Integer map(String otherType) {
    		Integer result = otherType.length() + 10;
    		return result;
    	}
    };
    return   /*<-- return of the result 
      which is obtained by invocation of static method of ListCreator class:
     */  ListCreator.collectFrom(src).when(sel).mapEvery(map);
  }

  public static void main(String[] args) {
    new Main();
  }
}
