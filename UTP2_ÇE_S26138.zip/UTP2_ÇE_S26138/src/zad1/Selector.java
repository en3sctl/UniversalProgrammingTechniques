/**
 *
 *  @author Çatal Enes S26138
 *
 */

package zad1;


public interface Selector<T> { // The interface must be parameterized

	public boolean select(T type);
	
}  
