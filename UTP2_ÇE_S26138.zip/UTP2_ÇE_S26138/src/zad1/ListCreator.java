/**
 *
 *  @author Çatal Enes S26138
 *
 */

package zad1;

import java.util.ArrayList;
import java.util.List;

public class ListCreator <T> { // The class must be parameterized 
	
	List<T> list;
	
	public ListCreator(List<T> list) {
		this.list = list;
	}
	
	public static <T> ListCreator<T> collectFrom(List<T> list){
		ListCreator listCreator = new ListCreator(list);
		return listCreator;
	}
	
	public ListCreator<T> when(Selector<T> sel){
		List<T> result = new ArrayList<T>();
		
		for(int i = 0; i < list.size(); i++) {
			if(sel.select(list.get(i))) {
				result.add(list.get(i));
			}
		}
		list = result;
		return this;
	}
	
	//"O" mean other
	public <O> List<O> mapEvery(Mapper<T,O> map){
		List<O> result2 = new ArrayList<O>();
		
		for(int i = 0; i < list.size(); i++) {
			{
				O o = (O)list.get(i);
				result2.add(map.map((T) o));
			}
		}
		
		return result2;
	}
}  
