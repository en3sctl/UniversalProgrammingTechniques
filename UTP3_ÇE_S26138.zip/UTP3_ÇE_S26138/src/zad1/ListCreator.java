package zad1;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class ListCreator<T> {
	private List<T> list;
	private List<T> listTemp;
	
	private ListCreator(List<T> list) {
		this.list = list;
	}
	
	public static<T> ListCreator<T> collectFrom(List<T> destinations){
		ListCreator<T> listCreator = new ListCreator<T> (destinations);
		return listCreator;
	}
	
	public ListCreator<T> when(Predicate <T> predicate){
		listTemp = new ArrayList<T>();
		
		for(int i = 0; i < list.size(); i++) {
			if(predicate.test(list.get(i))) {
				listTemp.add(list.get(i));
			}
		}
		this.list = listTemp;
		return this;
	}
	
	public <R> List<T> mapEvery(Function<T,R> u){
		listTemp = new ArrayList<T>();
		
		for(T e : list) {
			listTemp.add((T) u.apply(e));
		}
		this.list = listTemp;
		return list;
	}
}
