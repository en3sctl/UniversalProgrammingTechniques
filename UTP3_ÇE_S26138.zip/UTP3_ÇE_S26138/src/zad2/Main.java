/**
 *
 *  @author Çatal Enes S26138
 *
 */

package zad2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/*<-- necessary imports */

public class Main {

  public static void main(String[] args) {
    // List of destination: departure_airport destination_airport price_EUR
    List<String> dest = Arrays.asList(
      "bleble bleble 2000",
      "WAW HAV 1200",
      "xxx yyy 789",
      "WAW DPS 2000",
      "WAW HKT 1000"
    );
    double ratePLNvsEUR = 4.30;
    List<String> result = dest.stream().filter(n -> n.startsWith("WAW"))
    		.map(n -> {
    			String tokens[] = n.split(" ");
    			return "to " + tokens[1] + " - price in PLN: " + (int)(Double.parseDouble(tokens[2]) * ratePLNvsEUR);
    		})
    		.collect(Collectors.toCollection(ArrayList<String>::new));
    /*<-- here you should add fragment of code
     * but you are not allowed to use any own classes like eg ListCreator
     * or any own interfaces either 
     * Hint: you should use streams 
     */

    for (String r : result) System.out.println(r);
  }
}
